/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;

import Models.Tutor;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DELL
 */
public class ClassDAO {

    private Connection con;
    private String status = "OK";
    private PreparedStatement ps = null;
    ResultSet rs = null;

    public ClassDAO() {
        try {
            con = new DBContext().getConnection();
        } catch (Exception e) {
            status = "Error at connection" + e.getMessage();
        }
    }

    public void createClass(int parentID, int gender, int pay,
            int sessions, int time, String description, String date,
            String actualAddress,
            int tutorEdlevel,
            int subjectID,
            int numOfStudents
    ) {
        String query = "INSERT INTO [dbo].[Class]\n"
                + "          (\n"
                + "			 [ParentID]\n"
                + "			,[TutorGender]\n"
                + "			,[PayPerSession]\n"
                + "			,[SesPerWeek]\n"
                + "			,[TimeS]\n"
                + "			,[OpenDate]\n"
                + "			,[ClassDescription]\n"
                + "			,[ActualAddress]\n"
                + "			,[SubjectID]\n"
                + "			,[StudentNum]\n"
                + "			,[TutorEdLevel]"
                + ",[isApproved], [ClassStatus])\n"
                + "		  \n"
                + "    VALUES(?,?,?,?,?,?,?,?,?,?,?,0,1)\n";
        try {
            ps = con.prepareStatement(query);
            ps.setInt(1, parentID);
            ps.setInt(2, gender);
            ps.setInt(3, pay);
            ps.setInt(4, sessions);
            ps.setInt(5, time);
            ps.setString(6, date);
            ps.setNString(7, description);
            ps.setNString(8, actualAddress);
            ps.setInt(9, subjectID);
            ps.setInt(10, numOfStudents);
            ps.setInt(11, tutorEdlevel);
            ps.executeUpdate();
        } catch (SQLException e) {
        }

    }

    public void ManageAllClass_Id(int classID, boolean isApproved, String userName, String subjectName, int pay, int educationLevel) {
        List<Models.Class> listClassbyID = new ArrayList<>();
        String query = "SELECT "
                + "             Class.ClassID, Class.IsApproved, \n"
                + "		Account.UserName, \n"
                + "		Class.OpenDate,\n"
                + "		Subject.SubjectName, \n"
                + "		Class.PayPerSession, \n"
                + "		Tutor.EducationLevel\n"
                + "FROM Class \n"
                + "LEFT JOIN Account ON Class.ParentID = Account.AccountID \n"
                + "LEFT JOIN Tutor ON Tutor.TutorID = Class.TutorID \n"
                + "LEFT JOIN Subject ON Subject.SubjectID = Class.SubjectID\n"
                + "LEFT JOIN Tutor_Subject ON Tutor_Subject.SubjectID = Subject.SubjectID\n"
                + "WHERE Account.AccountID = ?";
        try {
            ps = con.prepareStatement(query);
            ps.setInt(1, classID);
            ps.setBoolean(2, isApproved);
            ps.setString(3, userName);
            ps.setString(4, subjectName);
            ps.setInt(5, pay);
            ps.setInt(6, educationLevel);

        } catch (SQLException e) {
        }
    }

    public void ParentClassDelete(int classId) {
        String query = "UPDATE Class\n"
                + "SET ClassStatus = 0\n"
                + "WHERE ClassID = ? and TutorID is null";

        try {
            con = new DBContext().getConnection();
            ps = con.prepareStatement(query);
            ps.setInt(1, classId);

            // Thực hiện câu truy vấn cập nhật
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean canDeleteClass(int classId) {
        try {
            con = new DBContext().getConnection();
            String query = "SELECT ClassStatus FROM Class WHERE ClassID = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, classId);
            rs = ps.executeQuery();

            if (rs.next()) {
                int classStatus = rs.getInt("ClassStatus");

                // Kiểm tra điều kiện để xác định có thể xoá lớp hay không
                return (classStatus == 0); // Giả sử 0 là trạng thái cho việc có thể xoá lớp
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Đóng kết nối và các đối tượng liên quan
            
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false; // Mặc định không xoá lớp nếu có lỗi xảy ra
    }

}
